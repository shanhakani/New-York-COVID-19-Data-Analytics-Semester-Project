import requests; from bs4 import BeautifulSoup; from pprint import pprint; import csv; import re; import numpy as np

def web_parser4(filename):

    resp = requests.get(filename)
    soup = BeautifulSoup(resp.text, "html.parser")
    name = soup.find_all("td")

    county_list = []
    population_list = []

    for item in name:
        if name.index(item) % 2 == 1:
            population_list.append(item)
        else:
            county_list.append(item)

    for i in range(len(county_list)):
        county_list[i] = str(county_list[i])[:-10]

    indexes = []
    for county in county_list:
        indexes.append([i.start() for i in re.finditer(">", county)])

    for i in range(len(county_list)):
        county_list[i] = county_list[i][(indexes[i][1]) + 1:]

    for i in range(len(population_list)):
        population_list[i] = int(str(population_list[i])[18:-5].replace(",", ""))

    population_dict = {}

    for i in range(len(county_list)):
        population_dict[county_list[i]] = population_list[i]

    with open("NY_Covid19_Data.csv") as f:
        reader = csv.reader(f, delimiter = ",", quotechar = '"')
        readerlist = list(reader)

    for county in readerlist:
        if county[0] in population_dict:
            county.append(population_dict[county[0]])
        else:
            county.append(np.nan)

    with open("NY_Covid19_Data.csv", "w") as fout:
        writer = csv.writer(fout, lineterminator = "\n")
        writer.writerows(readerlist)

    pprint(readerlist)
    print()

    return 'Data has been exported to "NY_Covid19_Data.csv"'


pprint(web_parser4("https://www.indexmundi.com/facts/united-states/quick-facts/new-york/population#table"))
