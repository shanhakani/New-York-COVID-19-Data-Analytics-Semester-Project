import csv; from pprint import pprint

def summary(filename):
    with open(filename) as f:
        reader=csv.reader(f,delimiter=",",quotechar='"')
        reader_list=list(reader)

        return reader_list

pprint(summary("NY_Covid19_Data.csv"))
pprint(summary("NY_Covid_Deaths.csv"))
pprint(summary("income_education.csv"))
