import requests; from bs4 import BeautifulSoup; from pprint import pprint; import csv

def web_parser3(filename):

    resp = requests.get(filename)
    soup = BeautifulSoup(resp.text, "html.parser")
    name = soup.find_all("td")

    county_list = []
    percent_list = []

    for item in name:
        if name.index(item) % 2 == 1:
            percent_list.append(item)
        else:
            county_list.append(item)

    for i in range(len(county_list)):
        county_list[i] = str(county_list[i])[4:-5]

    for i in range(len(percent_list)):
        percent_list[i] = float(str(percent_list[i])[18:-5])

    college_grad_dict = {}

    for i in range(len(county_list)):
        college_grad_dict[county_list[i]] = percent_list[i]

    with open("income_education.csv") as f:
        reader = csv.reader(f, delimiter = ",", quotechar = '"')
        readerlist = list(reader)

    for county in readerlist[1:]:
        county.append(college_grad_dict[county[0]])

    with open("income_education.csv", "w") as fout:
        writer = csv.writer(fout, lineterminator = "\n")
        writer.writerows(readerlist)

    pprint(readerlist)
    print()

    return 'Data has been exported to "income_education.csv"'


pprint(web_parser3("https://www.indexmundi.com/facts/united-states/quick-facts/new-york/percent-of-people-25-years-and-over-with-bachelors-degree-or-higher#table"))
