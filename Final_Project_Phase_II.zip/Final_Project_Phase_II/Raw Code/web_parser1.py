import requests; from bs4 import BeautifulSoup; from pprint import pprint; import csv

def web_parser1(filename):

    resp = requests.get(filename)
    soup = BeautifulSoup(resp.text, "html.parser")
    name = soup.find_all("td")
    county_list = []
    income_list = []
    for item in name:
        if name.index(item) % 2 == 1:
            income_list.append(item)
        else:
            county_list.append(item)

    counties = []
    incomes = []


    for county in county_list:
        counties.append(str(county)[4:-5])

    for income in income_list:
        incomes.append(str(income)[18:-5])

    median_income = []

    for income in incomes:
        if "," in income:
            income = income.replace(",", "")
            median_income.append(int(income))

    income_dict = {}

    for i in range(len(counties)):
        income_dict[counties[i]] = median_income[i]

    sorted_incomes = sorted(median_income, reverse = True)

    return_list = []

    for income in sorted_incomes:
        for key, value in income_dict.items():
            if value == income:
                return_list.append([key, value])

    return_list.insert(0, ["County", "Median Income", "Percent of Population with High School Diploma", "Percent of Population with Bachelor's Degree"])

    with open("income_education.csv", "w") as fout:
        writer = csv.writer(fout, lineterminator = "\n")
        writer.writerows(return_list)

    pprint(return_list)
    print()

    return 'Data has been exported to "income_education.csv"'





pprint(web_parser1("https://www.indexmundi.com/facts/united-states/quick-facts/new-york/median-household-income#table"))
