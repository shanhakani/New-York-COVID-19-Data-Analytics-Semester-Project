import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def insight2():

    df=pd.read_csv("NY_Covid_Deaths.csv")
    data=df[["All Ages","0-17 years","18-64 years","65+ years"]]
    data["Week"]=range(0,38)
    data.loc["Total Deaths",:]=data.sum(axis=0)
    data.to_csv("Age Group Deaths.csv", index = True)
    return data


print(insight2())
