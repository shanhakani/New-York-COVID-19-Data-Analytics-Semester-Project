import pandas as pd; from pprint import pprint; import numpy as np; import matplotlib.pyplot as plt

def visual2(filename):

    df = pd.read_csv(filename, delimiter = ",", index_col = 0)
    df.sort_values(by = "Percent of Population with Bachelor's Degree", ascending = False, inplace = True)


    q1 = df.iloc[0:14,:]
    q2 = df.iloc[14:28,:]
    q3 = df.iloc[28:42,:]
    q4 = df.iloc[42:, :]

    q1_counties = list(q1.index.values)
    q2_counties = list(q2.index.values)
    q3_counties = list(q3.index.values)
    q4_counties = list(q4.index.values)

    covid_df = pd.read_csv("NY_Covid19_Data.csv", delimiter = ",", index_col = 0)

    q1_data = []
    q2_data = []
    q3_data = []
    q4_data = []

    for county in q1_counties:
            q1_data.append(covid_df.loc[county, "Average Number of Cases per Day"])

    for county in q2_counties:
            q2_data.append(covid_df.loc[county, "Average Number of Cases per Day"])

    for county in q3_counties:
            q3_data.append(covid_df.loc[county, "Average Number of Cases per Day"])

    for county in q4_counties:
            q4_data.append(covid_df.loc[county, "Average Number of Cases per Day"])

    q1.loc[:, "Average Number of Cases per Day"] = q1_data
    q2.loc[:, "Average Number of Cases per Day"] = q2_data
    q3.loc[:, "Average Number of Cases per Day"] = q3_data
    q4.loc[:, "Average Number of Cases per Day"] = q4_data

    q1.loc["Average"] = q1.mean(axis=0).round(2)
    q2.loc["Average"] = q2.mean(axis=0).round(2)
    q3.loc["Average"] = q3.mean(axis=0).round(2)
    q4.loc["Average"] = q4.mean(axis=0).round(2)

    data = [q1.loc["Average"].loc["Average Number of Cases per Day"], q2.loc["Average"].loc["Average Number of Cases per Day"], q3.loc["Average"].loc["Average Number of Cases per Day"], q4.loc["Average"].loc["Average Number of Cases per Day"]]

    graph_df = pd.DataFrame({"Average Number of Cases per Day" : data, "Quartile" : ["Q1", "Q2", "Q3", "Q4"]})

    graph_df.plot(kind = 'bar', x = 'Quartile', y = 'Average Number of Cases per Day', color = 'red')

    plt.xlabel("Quartile")
    plt.ylabel("Average Number of Cases per Day")
    plt.title("College Education vs Average Number of Cases per Day by County Quartile")

    plt.show()


pprint(visual2("income_education.csv"))
