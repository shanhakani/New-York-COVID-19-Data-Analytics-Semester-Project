import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def line_graph():

    df=pd.read_csv("NY_Covid_Deaths.csv")
    data=df[["All Ages","0-17 years","18-64 years","65+ years"]]
    data["Week"]=range(0,38)


    ax1=plt.gca()
    data.plot(kind='line',x='Week',y='65+ years',color="blue",ax=ax1,title="COVID-19 Deaths by Age Group",xlabel="Week Number",ylabel="Deaths")
    data.plot(kind='line',x='Week',y='18-64 years',color="red",ax=ax1)
    data.plot(kind='line',x='Week',y='0-17 years',color="green",ax=ax1)
    data.plot(kind='line',x='Week',y='All Ages',color="black",ax=ax1)
    plt.savefig("COVID-19 by Age Group Line Graph")
    plt.show()



line_graph()
