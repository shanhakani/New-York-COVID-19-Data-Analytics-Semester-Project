import json
import csv
from pprint import pprint



def data_parser(filename):
    python_dict=json.load(open(filename))
    d_data=python_dict["data"]

    county_list=[]

    for county in d_data:
        if county not in county_list:
            county_list.append(county[9])

    county_list_final=sorted(list(set(county_list)),key=lambda x:x[0])


    first_case_index=[]
    date_of_fcase=[]

    for county in range(len(d_data)):
        if int(d_data[county][11]) != 0:
            if int(d_data[county-1][11])==0:
                first_case_index.append(county+2)
                date_of_fcase.append(d_data[county][8][0:10])


    last_case_index=[]
    date_of_lcase=[]
    for county in range(len(d_data)):
        if (d_data[county][8]) == "2020-10-25T00:00:00":
            last_case_index.append(county+2)
            date_of_lcase.append(d_data[county][8][0:10])



    cummulative_cases_per_county=[]
    for county in range(len(d_data)):
        if d_data[county][8]=="2020-10-25T00:00:00":
            cummulative_cases_per_county.append(int(d_data[county][11]))


    avg_rate_c=[]

    total_tests_performed=[]
    for county in range(len(d_data)):
        if d_data[county][8]=="2020-10-25T00:00:00":
            total_tests_performed.append(int(d_data[county][13]))


    for num in range(len(cummulative_cases_per_county)):
        avg_rate_c.append(round(((cummulative_cases_per_county[num])/(last_case_index[num]-first_case_index[num]+1)),2))



    final_dict={}
    counter=-1
    for county in county_list_final:
        counter+=1
        if county not in final_dict.keys():
            final_dict[county]={"Date of First Case":date_of_fcase[counter],"Date of Last Case":date_of_lcase[counter],
            "Total Cases":cummulative_cases_per_county[counter],"Average Number Cases per Day":avg_rate_c[counter],
            "Total Tests Performed":total_tests_performed[counter]}


    a_list = []
    a_list.append(["County", "Date of First Case", "Date of Last Case", "Total Cases", "Average Number of Cases per Day","Total Tests Performed", "Population"])

    for key, value in final_dict.items():
        counties = [key]
        for k, v in value.items():
            counties.append(v)
        a_list.append(counties)

    with open("NY_Covid19_Data.csv", "w") as fout:
        writer = csv.writer(fout, lineterminator = "\n")
        writer.writerows(a_list)

    pprint(a_list)
    print()
    return 'Data has been exported to "NY_Covid19_Data.csv"'

pprint(data_parser("Ny_Statewide_Covid19.json"))



