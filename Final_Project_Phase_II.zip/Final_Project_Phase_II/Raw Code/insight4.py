import pandas as pd; from pprint import pprint; import numpy as np

def insight4(filename):

    df = pd.read_csv(filename, delimiter = ",", index_col = 0)
    new_df = df[["Population", "Average Number of Cases per Day"]]
    new_df = new_df.dropna()

    new_df = new_df.sort_values(by = "Population", ascending = False, inplace = False)

    q1 = new_df.iloc[0:14,:]
    q2 = new_df.iloc[14:28,:]
    q3 = new_df.iloc[28:42,:]
    q4 = new_df.iloc[42:, :]

    q1.loc["Average"] = q1.mean(axis=0).round(2)
    q2.loc["Average"] = q2.mean(axis=0).round(2)
    q3.loc["Average"] = q3.mean(axis=0).round(2)
    q4.loc["Average"] = q4.mean(axis=0).round(2)

    return q1, q2, q3, q4

pprint(insight4("NY_Covid19_Data.csv"))
