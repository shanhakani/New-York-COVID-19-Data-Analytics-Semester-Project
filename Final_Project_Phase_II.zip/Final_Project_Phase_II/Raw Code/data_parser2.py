import csv
from pprint import pprint
import pandas as pd
import numpy as np

def data_parser2(filename):
    with open(filename) as f:
        reader=csv.reader(f,delimiter=",",quotechar='"')
        reader_list=list(reader)

        nyc_list=[]
        for city in reader_list:
            if city[7]=="New York":
                nyc_list.append([city[1],city[8],city[9],city[10]])

        return_list = [["All Ages", "0-17 years", "18-64 years", "65+ years"]]

        date_list = []
        for sublist in nyc_list:
            if sublist[0] not in date_list:
                date_list.append(sublist[0])


        for date in date_list:
            deaths = []
            for sublist in nyc_list:
                if date == sublist[0] and sublist[1] == "All Ages":
                    deaths.append(sublist[2])
                elif date == sublist[0] and sublist[1] == "0-17 years":
                    deaths.append(sublist[2])
                elif date == sublist[0] and sublist[1] == "18-64 years":
                    deaths.append(sublist[2])
                elif date == sublist[0] and sublist[1] == "65+ years":
                    deaths.append(sublist[2])
            return_list.append(deaths)

        for sublist in return_list:
            for value in sublist:
                if value == '':
                    sublist[sublist.index(value)] = np.nan


        deaths_arr = np.array(return_list)

        df = pd.DataFrame(data = deaths_arr[1:], columns = deaths_arr[0], index = date_list)

        df.to_csv("NY_Covid_Deaths.csv", index = True)

        pprint(df)
        print()

        return 'Data has been exported to "NY_Covid_Deaths.csv"'


pprint(data_parser2("COVID_Death.csv"))

