import pandas as pd
import numpy as np

def insight5():

    df=pd.read_csv("NY_Covid19_Data.csv")
    df.drop(["Date of First Case","Date of Last Case","Average Number of Cases per Day","nan"],axis=1,inplace=True)
    df.loc[:,"% of People Tested Positive"]=round((df["Total Cases"]/df["Total Tests Performed"])*100,2)
    df.sort_values(by="% of People Tested Positive",ascending=False,inplace=True)
    df.loc["Sum","Total Cases"]=df["Total Cases"].sum(axis=0)
    df.loc["Sum","Total Tests Performed"]=df["Total Tests Performed"].sum(axis=0)
    df.loc["Average","% of People Tested Positive"]=(df.loc["Sum","Total Cases"]/df.loc["Sum","Total Tests Performed"])*100
    df.to_csv("% of People Tested Positive.csv", index = True)


insight5()
