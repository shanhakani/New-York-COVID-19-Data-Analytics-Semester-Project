import pandas as pd; from pprint import pprint; import numpy as np; import matplotlib.pyplot as plt

def visual3(filename):

    df = pd.read_csv(filename, delimiter = ",", index_col = 0)
    new_df = df[["Population", "Average Number of Cases per Day"]]
    new_df = new_df.dropna()

    new_df = new_df.sort_values(by = "Population", ascending = False, inplace = False)

    q1 = new_df.iloc[0:14,:]
    q2 = new_df.iloc[14:28,:]
    q3 = new_df.iloc[28:42,:]
    q4 = new_df.iloc[42:, :]

    q1.loc["Average"] = q1.mean(axis=0).round(2)
    q2.loc["Average"] = q2.mean(axis=0).round(2)
    q3.loc["Average"] = q3.mean(axis=0).round(2)
    q4.loc["Average"] = q4.mean(axis=0).round(2)

    data = [q1.loc["Average"].loc["Average Number of Cases per Day"], q2.loc["Average"].loc["Average Number of Cases per Day"], q3.loc["Average"].loc["Average Number of Cases per Day"], q4.loc["Average"].loc["Average Number of Cases per Day"]]

    graph_df = pd.DataFrame({"Average Number of Cases per Day" : data, "Quartile" : ["Q1", "Q2", "Q3", "Q4"]})

    graph_df.plot(kind = 'bar', x = 'Quartile', y = 'Average Number of Cases per Day', color = 'blue')

    plt.xlabel("Quartile")
    plt.ylabel("Average Number of Cases per Day")
    plt.title("Population vs Average Number of Cases per Day by County Quartile")

    plt.show()

pprint(visual3("NY_Covid19_Data.csv"))
